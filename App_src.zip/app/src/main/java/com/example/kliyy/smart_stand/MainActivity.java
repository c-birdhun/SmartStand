package com.example.kliyy.smart_stand;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import app.akexorcist.bluetotohspp.library.BluetoothSPP;
import app.akexorcist.bluetotohspp.library.BluetoothService;
import app.akexorcist.bluetotohspp.library.BluetoothState;
import app.akexorcist.bluetotohspp.library.DeviceList;



public class MainActivity extends AppCompatActivity {

    public BluetoothSPP blue;
    public int sw_Flag = 0;
    private int de_Flag = 1;
    private int sd_Flag = 0;
    private int connect_Flag = 0;
    private String id=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE); // 풀스크린 만드는법
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        final ImageButton blue_sw = findViewById(R.id.blue_bt);
        blue = new BluetoothSPP(this); //Initializing
        if (!blue.isBluetoothAvailable()) { //블루투스가 기기에 장착되어있는지 확인
            Toast.makeText(getApplicationContext()
                    , "블루투스를 지원하지 않습니다.", Toast.LENGTH_SHORT).show();
            finish();
        }

        blue.setOnDataReceivedListener(new BluetoothSPP.OnDataReceivedListener() { //데이터 수신
            public void onDataReceived(byte[] data, String message) { //값을 받을때
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });

        blue.setBluetoothConnectionListener(new BluetoothSPP.BluetoothConnectionListener() { //연결됐을 때
            public void onDeviceConnected(String name, String address) {
                Toast.makeText(getApplicationContext()
                        , "디바이스:" + name + "\n" + address, Toast.LENGTH_SHORT).show();
                blue_sw.setSelected(true);
                connect_Flag = 1;
                start();
            }

            public void onDeviceDisconnected() { //연결해제
                Toast.makeText(getApplicationContext(), "연결 종료", Toast.LENGTH_SHORT).show();
                blue_sw.setSelected(false);
                connect_Flag = 0;
                start();
            }

            public void onDeviceConnectionFailed() { //연결실패
                Toast.makeText(getApplicationContext()
                        , "연결 실패", Toast.LENGTH_SHORT).show();
                blue_sw.setSelected(false);
                connect_Flag = 0;
            }
        });

        ImageButton blue_Connect = findViewById(R.id.blue_bt); //연결시도
        blue_Connect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (blue.getServiceState() == BluetoothState.STATE_CONNECTED) {
                    blue.disconnect();
                } else {
                    Intent intent = new Intent(getApplicationContext(), list.class);
                    startActivityForResult(intent, BluetoothState.REQUEST_CONNECT_DEVICE);
                }
            }
        });
    }

    public void onStart() {
        super.onStart();

        try{
            SharedPreferences save=getSharedPreferences("mybt",Activity.MODE_PRIVATE);
            id=save.getString("int_save","bt_id");
            }catch(ExceptionInInitializerError e){



        }
blue.setAutoConnectionListener(new BluetoothSPP.AutoConnectionListener() {
    @Override
    public void onAutoConnectionStarted() {
     
    }

    @Override
    public void onNewConnection(String name, String address) {

    }
});
        if (!blue.isBluetoothEnabled()) {
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent, BluetoothState.REQUEST_ENABLE_BT);
        } else {
            if (!blue.isServiceAvailable()) {
                blue.setupService();
                blue.startService(BluetoothState.DEVICE_OTHER);
                start();
            }
        }
    }

    public void onDestroy() {


        super.onDestroy();
        blue.stopService();
    }

    public void start() {
         final Switch sound_Sw = findViewById(R.id.sound);
        final Switch detection_Sw = findViewById(R.id.detection);
        final ImageButton blue_Send = findViewById(R.id.Sw);

        SharedPreferences save=getSharedPreferences("mybt",Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor=save.edit();
        editor.putString("int_save",blue.getConnectedDeviceAddress());


        if (connect_Flag == 1) {
            sound_Sw.setEnabled(true);
            detection_Sw.setEnabled(true);
            blue_Send.setEnabled(true);
        } else {
            sound_Sw.setEnabled(false);
            detection_Sw.setEnabled(false);
            blue_Send.setEnabled(false);
        }
        blue_Send.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (sw_Flag == 0) {
                    blue.send("1", true);
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    blue_Send.setSelected(true);
                    sw_Flag = 1;
                } else {
                    blue.send("0", true);
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    blue_Send.setSelected(false);
                    sw_Flag = 0;
                }
            }
        });

        sound_Sw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sd_Flag == 0) {
                    blue.send("3", true);
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    sd_Flag = 1;
                } else {
                    blue.send("2", true);
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    sd_Flag = 0;
                }
            }
        });

        detection_Sw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (de_Flag == 0) {
                    blue.send("4", true);
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    de_Flag = 1;
                } else {
                    blue.send("5", true);
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    de_Flag = 0;
                }
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
       if (requestCode == BluetoothState.REQUEST_CONNECT_DEVICE) {
            if (resultCode == Activity.RESULT_OK){
                blue.connect(data);}
            } else if (requestCode == BluetoothState.REQUEST_ENABLE_BT) {
                if (resultCode == Activity.RESULT_OK) {
                    blue.setupService();
                    blue.startService(BluetoothState.DEVICE_OTHER);
                    start();
                } else {
                    Toast.makeText(getApplicationContext()
                            , "블루투스 연결 실패." + data
                            , Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        }


    }

