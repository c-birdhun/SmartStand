package com.example.kliyy.smart_stand;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Set;

public class list extends Activity {


     // Tag for Log

    private static final String TAG = "DeviceListActivity";


      // 인텐트 리턴

    public static String EXTRA_DEVICE_ADDRESS = "device_address";


     // 멤버 변수들

    private BluetoothAdapter mBtAdapter;


     // 새로운 기기 부터

    private ArrayAdapter<String> mNewDevicesArrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Setup the window
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        setContentView(R.layout.activity_list);

        // Set result CANCELED in case the user backs out
        setResult(Activity.RESULT_CANCELED);

        // 기기 검색 버튼
        Button scanButton = (Button) findViewById(R.id.button_scan);
        scanButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                doDiscovery();
                v.setVisibility(View.GONE);
            }
        });

        //  전에 사용되어져 등록되어있는 디바이스 들과 검색을 이용해 찾은 디바이스를 표현할 리스트 뷰를 구성한다.
        ArrayAdapter<String> pairedDevicelist =
                new ArrayAdapter<String>(this, R.layout.device_name);
        mNewDevicesArrayAdapter = new ArrayAdapter<String>(this, R.layout.device_name);

        // Find and set up the ListView for paired devices
        ListView pairedListView = (ListView) findViewById(R.id.paired_devices);
        pairedListView.setAdapter(pairedDevicelist);
        pairedListView.setOnItemClickListener(mDeviceClickListener);

        // Find and set up the ListView for newly discovered devices
        ListView newDevicesListView = (ListView) findViewById(R.id.new_devices);
        newDevicesListView.setAdapter(mNewDevicesArrayAdapter);
        newDevicesListView.setOnItemClickListener(mDeviceClickListener);

        // 디바이스를 찾고 있을때 브로드캐스트 레지스터를 작동시킨다.
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);  //디바이스중 찾은것들만
        this.registerReceiver(mReceiver, filter);

        // 디바이스를 찾는걸 끝낼때 브로드캐스트 레지스터를 작동시킨다.
        filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED); //어댑터를 이용하여 찾는걸 종료했을시 찾은것들만
        this.registerReceiver(mReceiver, filter);

        // local Bluetooth adapter
        mBtAdapter = BluetoothAdapter.getDefaultAdapter();

        // 페어링된 기기들을 리스트에 정리한다.
        Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();

        // 기기검색시 처리
        if (pairedDevices.size() > 0) { //기기 검색 내용이 있을경우 (slave 가 페어링 중일경우)
            findViewById(R.id.title_paired_devices).setVisibility(View.VISIBLE);
            for (BluetoothDevice device : pairedDevices) {
                pairedDevicelist.add(device.getName() + "\n" + device.getAddress());
            }
        } else { // 기기가 없을시
            String noDevices = getResources().getText(R.string.none_paired).toString();
            pairedDevicelist.add(noDevices);
        }
    }

    @Override //종료시
    protected void onDestroy() {
        super.onDestroy();

        // 기기를 아무것도 찾지 못했을 경우
        if (mBtAdapter != null) {
            mBtAdapter.cancelDiscovery();
        }

        // 브로드 캐스트 리시버를 종료한다.
        this.unregisterReceiver(mReceiver);
    }


     // BluetoothAdapter 를 이용해 찾는다.
    private void doDiscovery() {
        Log.d(TAG, "doDiscovery()");

        // Indicate scanning in the title
        setProgressBarIndeterminateVisibility(true);
        setTitle(R.string.scanning);

        // Turn on sub-title for new devices
        findViewById(R.id.title_new_devices).setVisibility(View.VISIBLE);

        // If we're already discovering, stop it
        if (mBtAdapter.isDiscovering()) {
            mBtAdapter.cancelDiscovery();
        }

        // Request discover from BluetoothAdapter
        mBtAdapter.startDiscovery();
    }


     //ListView 들중 하나 를 선택 했을시에 나오는 이벤트
    private AdapterView.OnItemClickListener mDeviceClickListener
            = new AdapterView.OnItemClickListener() {
        public void onItemClick(AdapterView<?> av, View v, int arg2, long arg3) {
            // Cancel discovery because it's costly and we're about to connect
            mBtAdapter.cancelDiscovery();

            // Get the device MAC address, which is the last 17 chars in the View
            String info = ((TextView) v).getText().toString();
            String address = info.substring(info.length() - 17);
 // Create the result Intent and include the MAC address
            Intent intent = new Intent();
            intent.putExtra(EXTRA_DEVICE_ADDRESS, address);

            // Set result and finish this Activity
            setResult(Activity.RESULT_OK, intent);
            finish();
        }
    };// 인텐트 객체를 통해 메인 액티브 창으로 이동하면서 주소를 전달 하게 된다.

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            // When discovery finds a device
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // Get the BluetoothDevice object from the Intent
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                // If it's already paired, skip it, because it's been listed already
                if (device.getBondState() != BluetoothDevice.BOND_BONDED) {
                    mNewDevicesArrayAdapter.add(device.getName() + "\n" + device.getAddress());
                }
                // When discovery is finished, change the Activity title
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                setProgressBarIndeterminateVisibility(false);
                setTitle(R.string.select_device);
                if (mNewDevicesArrayAdapter.getCount() == 0) {
                    String noDevices = getResources().getText(R.string.none_found).toString();
                    Toast.makeText(context, noDevices, Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

}
