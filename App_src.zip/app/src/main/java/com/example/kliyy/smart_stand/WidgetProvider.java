package com.example.kliyy.smart_stand;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RemoteViews;

import java.util.Locale;

public class WidgetProvider extends AppWidgetProvider {

    @Override
    public void onEnabled(Context context) {  //위젯 생성시에 호출
        super.onEnabled(context);

    }
    MainActivity main=new MainActivity();
    int sw =0;

    @Override
    public void onReceive(Context context, Intent intent) {//브로드 캐스트 리시버
        super.onReceive(context, intent);

    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) { // 갱신시 호출
        super.onUpdate(context, appWidgetManager, appWidgetIds);
        appWidgetIds =appWidgetManager.getAppWidgetIds(new ComponentName(context,getClass()));

    }
    @Override
    public void onDisabled(Context context) { // 마지막 위젯 인스턴트 제거 될때 호출
        super.onDisabled(context);
    }
    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {  //사용자에 의해 제거될때 호출
        super.onDeleted(context, appWidgetIds);
    }
    public void widget_click(View v){

      //  final ImageButton bull = findViewById(R.id.widget_bt);
     if(sw==0){
         main.blue.send("1",true);
         sw=1;
         }
     else {
         main.blue.send("0",true);
         sw=0;
     }
    }
}
